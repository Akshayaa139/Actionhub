// src/pages/Reports.js
import React from "react";
import { Line, Pie } from "react-chartjs-2";
import "../styles/Reports.css";

const Reports = () => {
  const taskData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    datasets: [
      {
        label: "Tasks Completed",
        data: [12, 19, 3, 5, 2, 3],
        borderColor: "#4a90e2",
        tension: 0.4,
      },
    ],
  };

  const priorityData = {
    labels: ["High", "Medium", "Low"],
    datasets: [
      {
        data: [12, 19, 3],
        backgroundColor: ["#ff6384", "#36a2eb", "#cc65fe"],
      },
    ],
  };

  return (
    <div className="reports-container">
      <h2>Analytics Reports</h2>
      <div className="charts-grid">
        <div className="chart-card">
          <h3>Task Completion Trend</h3>
          <Line data={taskData} />
        </div>
        <div className="chart-card">
          <h3>Task Priority Distribution</h3>
          <Pie data={priorityData} />
        </div>
      </div>
    </div>
  );
};

export default Reports;
