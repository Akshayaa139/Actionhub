import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Dashboard.css';

const Dashboard = () => {
  const navigate = useNavigate();
  const [isSidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isProfileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notificationCount, setNotificationCount] = useState(3);
  const [notifications, setNotifications] = useState([
    { id: 1, message: 'New task assigned', time: '5m ago', unread: true },
    { id: 2, message: 'Team meeting in 30m', time: '10m ago', unread: true },
    { id: 3, message: 'Project deadline updated', time: '1h ago', unread: true }
  ]);
  
  const [showNotifications, setShowNotifications] = useState(false); // ✅ Fix for undefined state

  const [userProfile, setUserProfile] = useState({
    name: 'John Doe',
    level: 5,
    points: 250,
    nextLevel: 300,
    avatar: '👤'
  });

  const [stats, setStats] = useState({
    weeklyTasks: 12,
    totalPoints: 250,
    teamMembers: 5,
    dueTasks: 8,
    completionRate: '85%',
    trend: '+15%'
  });

  const [recentActivity, setRecentActivity] = useState([
    { id: 1, task: 'Website Design', time: '2 hours ago', type: 'completion' },
    { id: 2, task: 'API Integration', time: '3 hours ago', type: 'started' },
    { id: 3, task: 'Bug Fix #123', time: '5 hours ago', type: 'review' }
  ]);

  const [progress, setProgress] = useState({
    tasks: { completed: 12, total: 15 },
    points: { earned: 250, total: 300 },
    challenges: { completed: 3, total: 5 }
  });

  useEffect(() => {
    setUserProfile((prev) => ({ ...prev, points: 270 }));
    setStats((prev) => ({ ...prev, weeklyTasks: 14, trend: '+18%' }));
    setRecentActivity((prev) => [
      ...prev,
      { id: 4, task: 'UI Improvement', time: '30 minutes ago', type: 'update' }
    ]);
    setProgress((prev) => ({
      ...prev,
      tasks: { completed: 14, total: 15 }
    }));
  }, []);

  const handleNotificationClick = (id) => {
    setNotifications((prev) =>
      prev.map((notif) =>
        notif.id === id ? { ...notif, unread: false } : notif
      )
    );
    setNotificationCount((prev) => Math.max(0, prev - 1));
  };

  const handleLogout = () => {
    navigate('/login');
  };

  const sidebarItems = [
    { icon: '📊', label: 'Dashboard', path: '/dashboard', active: true },
    { icon: '✓', label: 'Tasks', path: '/tasks' },
    { icon: '🏆', label: 'Achievements', path: '/achievements' },
    { icon: '👥', label: 'Team', path: '/team' },
    { icon: '📈', label: 'Reports', path: '/reports' },
    { icon: '⚙️', label: 'Settings', path: '/settings' }
  ];

  return (
    <div className="app-container">
      {/* Sidebar */}
      <div className={`sidebar ${isSidebarCollapsed ? 'collapsed' : ''}`}>
        <div className="sidebar-header">
          <div className="app-brand">
            <span className="app-icon">🚀</span>
            {!isSidebarCollapsed && <h2>ActionHub</h2>}
          </div>
          <button
            className="collapse-button"
            onClick={() => setSidebarCollapsed(!isSidebarCollapsed)}
          >
            {isSidebarCollapsed ? '→' : '←'}
          </button>
        </div>

        <div className="sidebar-user">
          <div className="user-avatar">{userProfile.avatar}</div>
          {!isSidebarCollapsed && (
            <div className="user-info">
              <h3>{userProfile.name}</h3>
              <div className="level-badge">
                Level {userProfile.level}
                <div className="level-progress">
                  <div
                    className="level-fill"
                    style={{
                      width: `${(userProfile.points / userProfile.nextLevel) * 100}%`
                    }}
                  ></div>
                </div>
              </div>
            </div>
          )}
        </div>

        <nav className="sidebar-nav">
          {sidebarItems.map((item, index) => (
            <button
              key={index}
              className={`nav-item ${item.active ? 'active' : ''}`}
              onClick={() => navigate(item.path)}
            >
              <span className="nav-icon">{item.icon}</span>
              {!isSidebarCollapsed && <span>{item.label}</span>}
            </button>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <div className={`main-content ${isSidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
        <header className="content-header">
          <div className="search-bar">
            <span className="search-icon">🔍</span>
            <input
              type="text"
              placeholder="Search tasks, projects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="user-menu">
            {/* Notifications */}
            <div className="notifications">
              <button
                className="notification-btn"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                🔔
                {notificationCount > 0 && (
                  <span className="notification-badge">{notificationCount}</span>
                )}
              </button>

              {showNotifications && (
                <div className="notifications-dropdown">
                  <div className="notifications-header">
                    <h4>Notifications</h4>
                    <button
                      className="mark-read"
                      onClick={() => {
                        setNotifications(prev =>
                          prev.map(n => ({ ...n, unread: false }))
                        );
                        setNotificationCount(0);
                      }}
                    >
                      Mark all as read
                    </button>
                  </div>
                  {notifications.map(notification => (
                    <div
                      key={notification.id}
                      className={`notification-item ${notification.unread ? 'unread' : ''}`}
                      onClick={() => handleNotificationClick(notification.id)}
                    >
                      <div className="notification-content">
                        <p>{notification.message}</p>
                        <span className="notification-time">{notification.time}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Profile Dropdown */}
            <div className="profile-dropdown">
              <button
                className="profile-button"
                onClick={() => setProfileDropdownOpen(!isProfileDropdownOpen)}
              >
                <span className="avatar">{userProfile.avatar}</span>
                <span className="name">{userProfile.name}</span>
              </button>

              {isProfileDropdownOpen && (
                <div className="dropdown-menu">
                  <button onClick={() => navigate('/profile')}>Profile</button>
                  <button onClick={() => navigate('/settings')}>Settings</button>
                  <button onClick={handleLogout}>Logout</button>
                </div>
              )}
            </div>
          </div>
        </header>

        <div className="dashboard-container">
          <h3>Recent Activity</h3>
          <ul>
            {recentActivity.map((activity) => (
              <li key={activity.id}>{activity.task} - {activity.time}</li>
            ))}
          </ul>

          <h3>Progress</h3>
          <p>Tasks Completed: {progress.tasks.completed} / {progress.tasks.total}</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

