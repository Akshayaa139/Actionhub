import React, { useState } from 'react';
import "../styles/Profile.css";

const Profile = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    name: 'John Doe',
    email: 'john.doe@example.com',
    level: 5,
    totalPoints: 250,
    joinDate: '2024-01-01',
    completedTasks: 45,
    achievements: 12
  });

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleSave = () => {
    setIsEditing(false);
    // Add API call to save profile data
  };

  return (
    <div className="profile-container">
      <div className="profile-header">
        <h2>Profile</h2>
        <button 
          className={`edit-button ${isEditing ? 'saving' : ''}`}
          onClick={isEditing ? handleSave : handleEdit}
        >
          {isEditing ? 'Save Changes' : 'Edit Profile'}
        </button>
      </div>
      
      <div className="profile-content">
        <div className="profile-info">
        
<div className="avatar-section">
  <div className="avatar">
    {profileData.profilePic ? (
      <img src={profileData.profilePic} alt="Profile" />
    ) : (
      <span>{profileData.name.charAt(0)}</span>
    )}
    <input
      type="file"
      accept="image/*"
      onChange={(e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            setProfileData({...profileData, profilePic: event.target.result});
          };
          reader.readAsDataURL(file);
        }
      }}
    />
  </div>
  <div className="level-badge">
    Level {profileData.level}
  </div>
</div>

          {Object.entries(profileData).map(([key, value]) => (
            <div className="info-group" key={key}>
              <label>{key.charAt(0).toUpperCase() + key.slice(1)}:</label>
              {isEditing && key !== 'level' && key !== 'totalPoints' ? (
                <input
                  type="text"
                  value={value}
                  onChange={(e) => 
                    setProfileData({...profileData, [key]: e.target.value})
                  }
                />
              ) : (
                <span>{value}</span>
              )}
            </div>
          ))}
        </div>

        <div className="profile-stats">
          <div className="stat-card">
            <h4>Tasks Completed</h4>
            <div className="value">{profileData.completedTasks}</div>
          </div>
          <div className="stat-card">
            <h4>Achievements</h4>
            <div className="value">{profileData.achievements}</div>
          </div>
          <div className="stat-card">
            <h4>Total Points</h4>
            <div className="value">{profileData.totalPoints}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;